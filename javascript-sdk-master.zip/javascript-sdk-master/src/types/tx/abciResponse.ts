export interface abciQueryResponseResult {
  response: abciQueryResponse
}

interface abciQueryResponse {
  value: string
}
