
# Class: Stake

Stake

## Hierarchy

* **Stake**

## Index

### Constructors

* [constructor](stake.md#constructor)

## Constructors

###  constructor

\+ **new Stake**(`bncClient`: [BncClient](bncclient.md)): *[Stake](stake.md)*

**Parameters:**

Name | Type | Description |
------ | ------ | ------ |
`bncClient` | [BncClient](bncclient.md) |   |

**Returns:** *[Stake](stake.md)*
